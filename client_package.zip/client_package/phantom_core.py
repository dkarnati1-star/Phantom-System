"""
phantom_core.py: everything that talks to the board and makes the data. No window code here.

The path of one number, in order:
  1. build the pump voltage      command_samples():  DC + AC x shape, one value per 20 ms
  2. send it, read the sensors   Board.step():       "STEP volts" in, "D,t_ms,seq,raw1,ok1,raw2,ok2,pump_v" out
  3. zero with the pump off      measure_zero():     median raw counts, 3 s
  4. counts to mmHg              (raw - zero) x gain, gain = psi x 51.7149 / 3276
  5. save                        save_run():         runs/<time>_<tag>/data.csv + meta.json

There is no feedback: the voltage is never changed by what the sensors read. Whatever pressure shape appears is the
response of the pump and phantom to the voltage that was commanded.
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import sys
import time
from pathlib import Path

import numpy as np

BAUD = 115200
RATE = 50                                  # samples per second; the board answers one STEP per sample
MAX_V = 3.3                                # the DAC is powered from 3.3 V, so the pump never gets more
PSI_TO_MMHG = 51.7149
SPAN_COUNTS = 4095 * 0.80                  # the sensor output spans 10 to 90 % of the ADC range
LIMIT_MMHG = {15: 300.0, 5: 200.0}         # the pump stops if P1 or P2 stays above this (3 samples in a row)
SHAPES = ("flat", "sine", "two-sine", "human")
HERE = Path(sys.executable).parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
RUNS = HERE / "runs"                       # one folder per run, next to the program
COLUMNS = ["pc_time", "board_ms", "seq", "cmd_V", "pump_V", "p1_raw", "p2_raw", "p1_mmHg", "p2_mmHg", "ok1", "ok2"]


def gain(psi: float) -> float:
    """mmHg per ADC count for a sensor of this range (15 psi: 0.2368, 5 psi: 0.0789)."""
    return psi * PSI_TO_MMHG / SPAN_COUNTS


# ------------------------------------------------------------------------ 1. the pump voltage
_HUMAN = np.array([
    (0.00, 0.01), (0.04, 0.05), (0.08, 0.20), (0.10, 0.38), (0.12, 0.60), (0.14, 0.80), (0.16, 0.95), (0.18, 1.00),
    (0.20, 0.95), (0.22, 0.83), (0.24, 0.66), (0.26, 0.53), (0.28, 0.44), (0.30, 0.39), (0.33, 0.37), (0.36, 0.40),
    (0.40, 0.48), (0.45, 0.54), (0.50, 0.50), (0.56, 0.38), (0.62, 0.31), (0.68, 0.28), (0.74, 0.24), (0.80, 0.18),
    (0.86, 0.17), (0.90, 0.16), (0.94, 0.10), (0.97, 0.04)])   # arterial pulse: peak 18 %, notch 33 %, second peak 45 %


def _norm01(x: np.ndarray) -> np.ndarray:
    return (x - x.min()) / (x.max() - x.min())


def shape01(shape: str, n: int) -> np.ndarray:
    """One beat of n samples, scaled 0 (lowest) to 1 (highest)."""
    x = np.linspace(0.0, 1.0, n, endpoint=False)
    if shape == "flat":
        return np.zeros(n)
    if shape == "sine":
        return 0.5 - 0.5 * np.cos(2 * np.pi * x)
    if shape == "two-sine":
        return _norm01(np.sin(2 * np.pi * x) + 0.8 * np.sin(4 * np.pi * x))
    if shape == "human":
        raw = np.interp(x, _HUMAN[:, 0], _HUMAN[:, 1], period=1.0)
        sigma = 0.015 * n                                    # light smoothing removes the corners, keeps the notch
        half = max(1, int(4 * sigma))
        k = np.exp(-0.5 * (np.arange(-half, half + 1) / sigma) ** 2)
        k /= k.sum()
        return _norm01(np.convolve(np.concatenate([raw[-half:], raw, raw[:half]]), k, mode="valid"))
    raise ValueError(f"unknown shape {shape!r}; choose from {SHAPES}")


def check_inputs(ac: float, dc: float, hr: float, seconds: float) -> None:
    if ac < 0 or dc < 0:
        raise ValueError("AC and DC cannot be negative.")
    if dc + ac > MAX_V + 1e-9:
        raise ValueError(f"DC + AC is {dc + ac:g} V; the pump cannot get more than {MAX_V:g} V.")
    if hr <= 0 or seconds <= 0:
        raise ValueError("Heart rate and run time must be above 0.")


def command_samples(shape: str, ac: float, dc: float, hr: float, seconds: float) -> np.ndarray:
    """Pump voltage for every 20 ms of the run: DC + AC x shape (AC 0 gives a flat line at DC)."""
    check_inputs(ac, dc, hr, seconds)
    beat = dc + ac * shape01(shape, int(round(RATE * 60.0 / hr)))
    n = int(round(seconds * RATE))
    return np.resize(beat, n)


def waveform_test_samples(ac: float, dc: float, hr: float, each_s: float = 20.0):
    """Sine, two-sine and human one after another at the same AC and DC. Returns (samples, segments)."""
    parts, segs, t = [], [], 0.0
    for shape in ("sine", "two-sine", "human"):
        parts.append(command_samples(shape, ac, dc, hr, each_s))
        segs.append({"shape": shape, "start_s": t, "end_s": t + each_s})
        t += each_s
    return np.concatenate(parts), segs


# ------------------------------------------------------------------------ 2. the board
def find_port() -> str:
    from serial.tools import list_ports
    ports = list(list_ports.comports())
    for p in ports:
        if p.vid in (0x2341, 0x2A03) or "portenta" in f"{p.description}".lower() or "arduino" in f"{p.description}".lower():
            return p.device
    if len(ports) == 1:
        return ports[0].device
    raise RuntimeError("No board found. Ports seen: " + (", ".join(p.device for p in ports) or "none") +
                       ". Plug the Portenta in by USB and close the Arduino Serial Monitor.")


class Board:
    """The Portenta running Phantom_HW_executor.ino."""

    def __init__(self, port: str | None = None):
        import serial
        self.port = port or find_port()
        self.ser = serial.Serial(self.port, BAUD, timeout=0.5, write_timeout=1.0)
        time.sleep(2.0)
        self.ser.reset_input_buffer()
        self._send("PING")
        if not self._wait("#PONG", 3.0):
            self.ser.close()
            raise RuntimeError("The board did not answer. Flash Phantom_HW_executor.ino and close the Serial Monitor.")
        self._send("CHECK")
        self.info = self._wait("#CHECK", 3.0) or ""
        if "system=READY" not in self.info:
            self.ser.close()
            raise RuntimeError(f"The board is not ready: {self.info or 'no #CHECK reply'}")

    def _send(self, text: str) -> None:
        self.ser.write((text + "\n").encode("ascii"))
        self.ser.flush()

    def _line(self) -> str:
        return self.ser.readline().decode("ascii", errors="replace").strip()

    def _wait(self, prefix: str, timeout: float) -> str | None:
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            line = self._line()
            if line.startswith(prefix):
                return line
        return None

    def step(self, volts: float) -> dict:
        """Send one pump voltage; return the board's reading taken at the same moment."""
        self._send(f"STEP {min(max(volts, 0.0), MAX_V):.5f}")
        end = time.monotonic() + 0.5
        while time.monotonic() < end:
            line = self._line()
            if line.startswith("#ERR"):
                raise RuntimeError(line)
            p = line.split(",")
            if p[0] == "D" and len(p) == 8:
                return {"board_ms": int(p[1]), "seq": int(p[2]), "raw1": float(p[3]), "ok1": p[4] == "1",
                        "raw2": float(p[5]), "ok2": p[6] == "1", "pump_v": float(p[7])}
        raise TimeoutError("No answer to STEP within 0.5 s")

    def off(self) -> None:
        self._send("PUMP OFF")
        self._wait("#OK,PUMP OFF", 1.0)

    def close(self) -> None:
        try:
            self.off()
        finally:
            self.ser.close()


class DemoBoard:
    """A stand-in for the rig, for practice and tests: dead time 0.1 s, lag 0.11 s, dead zone below 1.25 V, 95 mmHg per volt."""

    def __init__(self, seed: int = 0):
        self.rng = np.random.default_rng(seed)
        self.port, self.info = "demo", "#CHECK,p1=OK,p2=OK,dac=OK,system=READY (demo, no hardware)"
        self.queue = [0.0] * 5
        self.p, self.seq, self.ms = 0.0, 0, 0

    def step(self, volts: float) -> dict:
        v = min(max(volts, 0.0), MAX_V)
        self.queue.append(v)
        delayed = self.queue.pop(0)
        target = 95.0 * max(0.0, delayed - 1.25)                       # mmHg on the 15 psi scale
        self.p += (1.0 / RATE) / (0.11 + 1.0 / RATE) * (target - self.p)
        self.seq += 1
        self.ms += 20
        z, g = 180.0, gain(15)
        return {"board_ms": self.ms, "seq": self.seq, "raw1": z + self.p / g + self.rng.normal(0, 1.5), "ok1": True,
                "raw2": z - 3 + 0.93 * self.p / g + self.rng.normal(0, 1.5), "ok2": True, "pump_v": v}

    def off(self) -> None:
        self.step(0.0)

    def close(self) -> None:
        pass


# ------------------------------------------------------------------------ 3. zero, 4. counts to mmHg, run
def measure_zero(board, seconds: float = 3.0) -> dict:
    """Read both sensors with the pump off. The median is the zero; the spread tells whether it was steady."""
    board.off()
    p1, p2, tick = [], [], time.perf_counter()
    for _ in range(int(seconds * RATE)):
        s = board.step(0.0)
        if s["ok1"] and s["ok2"]:
            p1.append(s["raw1"])
            p2.append(s["raw2"])
        tick += 1.0 / RATE
        time.sleep(max(0.0, tick - time.perf_counter()))
    if len(p1) < RATE:
        raise RuntimeError("The sensors did not give a steady reading with the pump off.")
    return {"zero_p1": float(np.median(p1)), "zero_p2": float(np.median(p2)),
            "zero_spread_p1": float(np.std(p1)), "zero_spread_p2": float(np.std(p2))}


def run(board, volts: np.ndarray, zero: dict, psi: float, stop=lambda: False, on_row=None, pace: bool = True):
    """
    Play the voltage at 50 samples per second and record every answer. Returns (rows, why_it_ended).
    The pump goes off at the end, on STOP, if the board stops answering, and if P1 or P2 stays above the limit.
    """
    g, limit = gain(psi), LIMIT_MMHG[int(psi)]
    rows, over, why, tick = [], 0, "finished", time.perf_counter()
    try:
        for v in volts:
            if stop():
                why = "stopped by user"
                break
            s = board.step(float(v))
            p1 = (s["raw1"] - zero["zero_p1"]) * g if s["ok1"] else float("nan")
            p2 = (s["raw2"] - zero["zero_p2"]) * g if s["ok2"] else float("nan")
            row = {"pc_time": dt.datetime.now().isoformat(timespec="milliseconds"), "board_ms": s["board_ms"], "seq": s["seq"],
                   "cmd_V": round(float(v), 5), "pump_V": s["pump_v"], "p1_raw": s["raw1"], "p2_raw": s["raw2"],
                   "p1_mmHg": round(p1, 3), "p2_mmHg": round(p2, 3), "ok1": int(s["ok1"]), "ok2": int(s["ok2"])}
            rows.append(row)
            if on_row:
                on_row(row)
            top = max(p1 if p1 == p1 else 0.0, p2 if p2 == p2 else 0.0)
            over = over + 1 if top > limit else 0
            if over >= 3:
                why = f"pressure above {limit:g} mmHg: pump switched off"
                break
            if pace:
                tick += 1.0 / RATE
                wait = tick - time.perf_counter()
                if wait > 0:
                    time.sleep(wait)
                elif wait < -0.5:
                    tick = time.perf_counter()
    except (TimeoutError, RuntimeError, OSError) as exc:
        why = f"board error: {exc}"
    finally:
        try:
            board.off()
        except Exception:
            pass
    return rows, why


# ------------------------------------------------------------------------ test plans (automation)
def read_plan(path: Path | str) -> list[dict]:
    """A plan file is a CSV with the columns shape, ac, dc, hr, seconds (and optional rest_s). One row = one test."""
    with Path(path).open(newline="", encoding="utf-8-sig") as fh:
        table = list(csv.DictReader(fh))
    if not table:
        raise ValueError("The plan file has no rows.")
    plan = []
    for n, r in enumerate(table, start=2):
        try:
            row = {"shape": r["shape"].strip(), "ac": float(r["ac"]), "dc": float(r["dc"]), "hr": float(r["hr"]),
                   "seconds": float(r["seconds"]), "rest_s": float(r.get("rest_s") or 10.0)}
            if row["shape"] not in SHAPES:
                raise ValueError(f"shape must be one of {', '.join(SHAPES)}")
            check_inputs(row["ac"], row["dc"], row["hr"], row["seconds"])
        except (KeyError, ValueError, TypeError) as exc:
            raise ValueError(f"Plan file, line {n}: {str(exc).rstrip('.')}. Columns needed: shape, ac, dc, hr, seconds (rest_s optional).") from None
        plan.append(row)
    return plan


# ------------------------------------------------------------------------ 5. save and read back
def save_run(rows: list[dict], meta: dict, tag: str = "run", folder: Path | None = None) -> Path:
    out = folder or RUNS / f"{dt.datetime.now():%Y-%m-%d_%H-%M-%S}_{tag}"
    out.mkdir(parents=True, exist_ok=True)
    with (out / "data.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS)
        w.writeheader()
        w.writerows(rows)
    (out / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return out


def read_run(folder: Path | str):
    """Load data.csv (numeric columns as arrays) and meta.json from a run folder."""
    folder = Path(folder)
    with (folder / "data.csv").open(newline="", encoding="utf-8") as fh:
        table = list(csv.DictReader(fh))
    data = {c: np.array([float(r[c]) for r in table]) for c in COLUMNS if c != "pc_time"}
    meta = json.loads((folder / "meta.json").read_text(encoding="utf-8")) if (folder / "meta.json").exists() else {}
    return data, meta


def make_meta(*, shape: str, ac: float, dc: float, hr: float, seconds: float, psi: float, zero: dict, board, why: str,
              demo: bool, segments: list | None = None) -> dict:
    return {"created": dt.datetime.now().isoformat(timespec="seconds"), "shape": shape, "ac_V": ac, "dc_V": dc, "hr_bpm": hr,
            "seconds_planned": seconds, "psi": psi, "mmHg_per_count": gain(psi), **zero, "limit_mmHg": LIMIT_MMHG[int(psi)],
            "feedback": "none", "demo": demo, "port": board.port, "board_check": board.info, "ended": why,
            "segments": segments or [], "software": "phantom_core 1.0"}
