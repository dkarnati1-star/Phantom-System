"""
Phantom Lab: one window to run the pump, watch P1, P2 and the pump voltage, and check the data.

    python phantom_lab.py              (or double-click PhantomLab.exe)
    python phantom_lab.py --selftest   (no window, no board: a 5 s demo run through the whole chain)

1  Flash the Portenta once (firmware/Phantom_HW_executor), connect it by USB, close the Arduino Serial Monitor.
2  Choose the sensor scale, type AC and DC (or press "Flush air"), press START. The pump must be OFF at that moment:
   the sensors are zeroed first.
3  Watch P1 and P2 (top) and the pump voltage that produced them (bottom). When the run ends the data is checked
   and every run is saved in the runs folder: data.csv (for MATLAB), meta.json, report.txt, plot.png.
No feedback: the voltage you type is the voltage the pump gets. Opening the window never starts the pump.
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import os
import queue
import shutil
import sys
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import numpy as np

import phantom_core as core
import phantom_verify as verify

ZOOMS = ["6 s", "12 s", "30 s", "Whole run"]  # time windows for the two trace graphs
MIN_SPAN_MMHG = 5.0                           # never stretch noise: the pressure axis is at least this tall
# Target levels and the AC / DC pairs used for them in the earlier runs (archive/acdc_notebook_30min.csv): 22 s settle + 68 s record.
# They are starting points, not a guarantee: the earlier runs used the learning mode and the 15 psi scale.
LEVELS = {"custom": None, "hypo 90/60": (2.0, 0.42), "normo 120/80": (2.7, 0.27), "hyper 150/120": (2.4, 0.52)}
BG, CARD, BORDER, INK, MUTED, MAROON = "#F4F1F0", "#FFFFFF", "#E2D9D9", "#2B2024", "#6B6168", "#500000"
COLOR = {"PASS": "#1a7f37", "WARN": "#8A5A00", "FAIL": "#B3261E", "TODO": "#6B6168", "N/A": "#9A9090"}
FONT = "Segoe UI"


def run_one(board, cfg: dict, post, stop: threading.Event, folder: Path | None = None):
    """Zero, run, save and check one test on an open board. Returns (folder, checklist, meta)."""
    post("status", "Zeroing with the pump off ...")
    zero = core.measure_zero(board, 1.2 if cfg.get("fast") else 3.0)
    segs = None
    if cfg["test"]:
        volts, segs = core.waveform_test_samples(cfg["ac"], cfg["dc"], cfg["hr"])
    else:
        volts = core.command_samples(cfg["shape"], cfg["ac"], cfg["dc"], cfg["hr"], cfg["seconds"])
    post("beat", None if cfg["test"] or cfg["ac"] == 0 or cfg["shape"] == "flat" else 60.0 / cfg["hr"])
    post("status", "Running ...")
    rows, why = core.run(board, volts, zero, cfg["psi"], stop=stop.is_set, on_row=lambda r: post("row", r), pace=not cfg.get("fast"))
    meta = core.make_meta(shape="waveform test" if cfg["test"] else cfg["shape"], ac=cfg["ac"], dc=cfg["dc"], hr=cfg["hr"],
                          seconds=len(volts) / core.RATE, psi=cfg["psi"], zero=zero, board=board, why=why, demo=cfg["demo"], segments=segs)
    tag = "wavetest" if cfg["test"] else ("flush" if cfg["ac"] == 0 else f"{cfg['shape']}_AC{cfg['ac']:g}_DC{cfg['dc']:g}")
    folder = core.save_run(rows, meta, tag + ("_demo" if cfg["demo"] else ""), folder)
    return folder, verify.check_folder(folder), meta, rows


def open_board(cfg: dict, post):
    board = core.DemoBoard() if cfg["demo"] else core.Board(cfg["port"] or None)
    post("status", f"Connected ({board.port}).")
    return board


def run_job(cfg: dict, post, stop: threading.Event) -> None:
    """One test, off the window thread. Reports through post(kind, value)."""
    board = None
    try:
        board = open_board(cfg, post)
        folder, items, meta, _ = run_one(board, cfg, post, stop)
        post("done", (folder, items, meta))
    except Exception as exc:                  # noqa: BLE001  (anything: tell the user in plain words)
        post("error", str(exc))
    finally:
        if board is not None:
            try:
                board.close()
            except Exception:
                pass


def plan_job(plan: list[dict], cfg: dict, post, stop: threading.Event) -> None:
    """A whole plan file, test after test: rest with the pump off, zero, run, save, check. One summary CSV at the end."""
    board, summary = None, []
    out = core.RUNS / f"{dt.datetime.now():%Y-%m-%d_%H-%M-%S}_plan{'_demo' if cfg['demo'] else ''}"
    try:
        board = open_board(cfg, post)
        for n, row in enumerate(plan, start=1):
            if stop.is_set():
                break
            one = dict(cfg, **{k: row[k] for k in ("shape", "ac", "dc", "hr", "seconds")}, test=False)
            post("status", f"Test {n} of {len(plan)}: resting {row['rest_s']:g} s with the pump off ...")
            board.off()
            end = time.monotonic() + (0.0 if cfg.get("fast") else row["rest_s"])
            while time.monotonic() < end and not stop.is_set():
                time.sleep(0.2)
            if stop.is_set():
                break
            post("reset", None)
            folder, items, meta, rows = run_one(board, one, lambda k, v: post(k, f"Test {n} of {len(plan)}: {v}") if k == "status" else post(k, v), stop, out / f"{n:02d}_{one['shape']}_AC{one['ac']:g}_DC{one['dc']:g}")
            p1, p2 = np.array([r["p1_mmHg"] for r in rows]), np.array([r["p2_mmHg"] for r in rows])
            count = {s: sum(i["status"] == s for i in items) for s in ("PASS", "WARN", "FAIL")}
            summary.append({"test": n, "folder": folder.name, "shape": one["shape"], "ac_V": one["ac"], "dc_V": one["dc"], "hr_bpm": one["hr"],
                            "seconds": round(len(rows) / core.RATE, 1), "ended": meta["ended"], "psi": cfg["psi"],
                            "p1_mean": round(float(np.nanmean(p1)), 2), "p1_min": round(float(np.nanmin(p1)), 2), "p1_max": round(float(np.nanmax(p1)), 2),
                            "p2_mean": round(float(np.nanmean(p2)), 2), "p2_min": round(float(np.nanmin(p2)), 2), "p2_max": round(float(np.nanmax(p2)), 2),
                            "pass": count["PASS"], "warn": count["WARN"], "fail": count["FAIL"]})
            if meta["ended"] != "finished":
                break
        if summary:
            out.mkdir(parents=True, exist_ok=True)
            with (out / "plan_summary.csv").open("w", newline="", encoding="utf-8") as fh:
                w = csv.DictWriter(fh, fieldnames=list(summary[0]))
                w.writeheader()
                w.writerows(summary)
        post("plan_done", (out, summary, len(plan)))
    except Exception as exc:                  # noqa: BLE001
        post("error", str(exc))
    finally:
        if board is not None:
            try:
                board.close()
            except Exception:
                pass


class App:
    def __init__(self, root: tk.Tk):
        self.root, self.q, self.stop_ev, self.thread = root, queue.Queue(), threading.Event(), None
        self.t, self.p1, self.p2, self.cmd, self.echo = [], [], [], [], []
        self.folder = None
        self.period = None                                  # seconds per beat of the current run (None: flat or test)
        root.title("Phantom Lab")
        root.geometry("1360x900")
        root.minsize(1200, 800)
        root.configure(bg=BG)
        self._style()
        self._build()
        root.after(100, self._poll)
        root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ------------------------------------------------------------------ look
    def _style(self) -> None:
        st = ttk.Style()
        st.theme_use("clam")
        st.configure("TButton", font=(FONT, 10), padding=(10, 5), background="#EFE9E8", foreground=INK, bordercolor=BORDER)
        st.map("TButton", background=[("active", "#E5DCDB"), ("disabled", "#F4F1F0")], foreground=[("disabled", "#A9A0A0")])
        st.configure("Start.TButton", font=(FONT, 14, "bold"), foreground="white", background="#1a7f37", padding=(10, 9))
        st.map("Start.TButton", background=[("disabled", "#A8BDB0"), ("active", "#14692d")])
        st.configure("Stop.TButton", font=(FONT, 11, "bold"), foreground="white", background="#B3261E", padding=(14, 6))
        st.map("Stop.TButton", background=[("disabled", "#8A3A36"), ("active", "#8F1F19")], foreground=[("disabled", "#D9B8B6")])
        st.configure("TEntry", fieldbackground="white", bordercolor=BORDER, padding=4)
        st.configure("TCombobox", fieldbackground="white", bordercolor=BORDER, arrowcolor=MAROON, padding=3)
        st.configure("Card.TCheckbutton", background=CARD, foreground=INK, font=(FONT, 10))

    def _card(self, parent) -> tk.Frame:
        return tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1)

    def _build(self) -> None:
        head = tk.Frame(self.root, bg=MAROON)
        head.pack(fill="x")
        tk.Label(head, text="Phantom Lab", bg=MAROON, fg="white", font=(FONT, 16, "bold")).pack(side="left", padx=20, pady=11)
        self.stop_btn = ttk.Button(head, text="STOP", style="Stop.TButton", command=self.stop, state="disabled")
        self.stop_btn.pack(side="right", padx=(8, 18), pady=9)
        self.pump_var = tk.StringVar(value="Pump off")
        self.pump_lbl = tk.Label(head, textvariable=self.pump_var, bg="#2d0000", fg="#9be39b", font=(FONT, 10, "bold"), padx=12, pady=4)
        self.pump_lbl.pack(side="right", padx=4)
        self.link_var = tk.StringVar(value="Board not checked")
        tk.Label(head, textvariable=self.link_var, bg=MAROON, fg="#ffd27a", font=(FONT, 10, "bold")).pack(side="right", padx=16)

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=14, pady=12)
        body.columnconfigure(1, weight=1)
        body.rowconfigure(0, weight=1)

        # ---- left: settings
        left = self._card(body)
        left.grid(row=0, column=0, sticky="ns", padx=(0, 12))
        f = tk.Frame(left, bg=CARD)
        f.pack(padx=18, pady=12)
        self.v = {k: tk.StringVar(value=val) for k, val in
                  dict(psi="15 psi", level="custom", shape="two-sine", ac="0.6", dc="2.0", hr="60", seconds="60", port="").items()}
        self.demo = tk.BooleanVar(value=False)
        r = 0

        def title(text):
            nonlocal r
            tk.Label(f, text=text.upper(), bg=CARD, fg=MAROON, font=(FONT, 8, "bold")).grid(row=r, column=0, columnspan=3, sticky="w", pady=(10, 1))
            tk.Frame(f, bg=BORDER, height=1).grid(row=r + 1, column=0, columnspan=3, sticky="we", pady=(0, 4))
            r += 2

        def field(label, key, unit="", values=None, width=9):
            nonlocal r
            tk.Label(f, text=label, bg=CARD, fg=INK, font=(FONT, 10)).grid(row=r, column=0, sticky="w", pady=3)
            if values:
                w = ttk.Combobox(f, textvariable=self.v[key], values=values, width=width + 2, state="readonly")
            else:
                w = ttk.Entry(f, textvariable=self.v[key], width=width, justify="right", font=(FONT, 11))
            w.grid(row=r, column=1, padx=(12, 6), pady=3, sticky="e")
            tk.Label(f, text=unit, bg=CARD, fg=MUTED, font=(FONT, 10)).grid(row=r, column=2, sticky="w")
            r += 1
            return w

        title("Sensors")
        field("Scale", "psi", values=["15 psi", "5 psi"])
        tk.Label(f, text="Printed on the sensor: ABPDANT015 = 15 psi,\nABPDANT005 = 5 psi. Saved with every run.", bg=CARD, fg=MUTED,
                 font=(FONT, 8), justify="left").grid(row=r, column=0, columnspan=3, sticky="w")
        r += 1
        field("Port", "port", values=[""] + self._ports(), width=7)
        self.check_btn = ttk.Button(f, text="Check board", command=self.check_board)
        self.check_btn.grid(row=r, column=0, columnspan=3, sticky="we", pady=(4, 0))
        r += 1
        title("Pump voltage = DC + AC x shape")
        field("Target level", "level", values=list(LEVELS)).bind("<<ComboboxSelected>>", lambda _e: self.pick_level())
        field("Shape", "shape", values=list(core.SHAPES))
        field("AC (height)", "ac", "V")
        field("DC (level)", "dc", "V")
        field("Heart rate", "hr", "bpm")
        field("Run time", "seconds", "s")
        ttk.Button(f, text="Flush air: AC 0, DC 3.0, 60 s", command=self.preset_flush).grid(row=r, column=0, columnspan=3, sticky="we", pady=(6, 0))
        r += 1
        ttk.Checkbutton(f, text="Demo mode (no board)", variable=self.demo, style="Card.TCheckbutton").grid(row=r, column=0, columnspan=3, sticky="w", pady=(10, 2))
        r += 1
        self.start_btn = ttk.Button(f, text="START", style="Start.TButton", command=lambda: self.start(False))
        self.start_btn.grid(row=r, column=0, columnspan=3, sticky="we", pady=(4, 4))
        r += 1
        self.test_btn = ttk.Button(f, text="Waveform test (60 s)", command=lambda: self.start(True))
        self.test_btn.grid(row=r, column=0, columnspan=3, sticky="we")
        r += 1
        self.plan_btn = ttk.Button(f, text="Run a plan file ...", command=self.start_plan)
        self.plan_btn.grid(row=r, column=0, columnspan=3, sticky="we", pady=(4, 0))
        r += 1
        self.status = tk.StringVar(value="Ready. The pump is off.")
        tk.Label(f, textvariable=self.status, bg=CARD, fg=MUTED, font=(FONT, 10), wraplength=250, justify="left").grid(row=r, column=0, columnspan=3, sticky="w", pady=(10, 0))

        # ---- right: numbers, graph, checklist
        right = tk.Frame(body, bg=BG)
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=5)
        right.rowconfigure(2, weight=1)
        tiles = tk.Frame(right, bg=BG)
        tiles.grid(row=0, column=0, sticky="we")
        self.tile = {}
        for i, (key, name) in enumerate((("p1", "P1 inlet (mmHg)"), ("p2", "P2 outlet (mmHg)"), ("v", "Pump voltage (V)"))):
            c = self._card(tiles)
            c.grid(row=0, column=i, sticky="we", padx=(0 if i == 0 else 8, 0))
            tiles.columnconfigure(i, weight=1)
            tk.Label(c, text=name, bg=CARD, fg=MUTED, font=(FONT, 9)).pack(anchor="w", padx=14, pady=(8, 0))
            self.tile[key] = tk.StringVar(value="--")
            tk.Label(c, textvariable=self.tile[key], bg=CARD, fg=INK, font=(FONT, 24, "bold")).pack(anchor="w", padx=14, pady=(0, 8))

        plot = self._card(right)
        plot.grid(row=1, column=0, sticky="nsew", pady=(8, 0))
        bar = tk.Frame(plot, bg=CARD)
        bar.pack(fill="x", padx=14, pady=(8, 0))
        tk.Label(bar, text="Graph window (left)", bg=CARD, fg=MUTED, font=(FONT, 9)).pack(side="left")
        self.zoom = tk.StringVar(value=ZOOMS[1])
        zoom = ttk.Combobox(bar, textvariable=self.zoom, values=ZOOMS, width=10, state="readonly")
        zoom.pack(side="left", padx=8)
        zoom.bind("<<ComboboxSelected>>", lambda _e: self._draw())
        tk.Label(bar, text="The right graph lays every beat on top of the others: that is the pressure waveform.", bg=CARD, fg=MUTED,
                 font=(FONT, 9)).pack(side="left", padx=14)
        from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
        from matplotlib.figure import Figure
        self.fig = Figure(figsize=(9, 4.2), dpi=100, facecolor="white")
        gs = self.fig.add_gridspec(2, 2, width_ratios=[1.35, 1], height_ratios=[3, 2])
        self.ax1 = self.fig.add_subplot(gs[0, 0])
        self.ax2 = self.fig.add_subplot(gs[1, 0], sharex=self.ax1)
        self.ax3 = self.fig.add_subplot(gs[:, 1])
        self.ax3v = self.ax3.twinx()
        self.canvas = FigureCanvasTkAgg(self.fig, master=plot)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=4, pady=4)
        self._draw()

        chk = self._card(right)
        chk.grid(row=2, column=0, sticky="nsew", pady=(8, 0))
        tk.Label(chk, text="DATA CHECK", bg=CARD, fg=MAROON, font=(FONT, 8, "bold")).pack(anchor="w", padx=14, pady=(8, 0))
        self.report = tk.Text(chk, height=12, bg=CARD, fg=INK, font=("Consolas", 9), relief="flat", wrap="word", padx=10, pady=4)
        for tag, col in COLOR.items():
            self.report.tag_configure(tag, foreground=col, font=("Consolas", 9, "bold"))
        self.report.pack(fill="both", expand=True)
        self._say("The checklist appears here after each run.")
        foot = tk.Frame(right, bg=BG)
        foot.grid(row=3, column=0, sticky="we", pady=(8, 0))
        ttk.Button(foot, text="Open run folder", command=self.open_run).pack(side="left")
        ttk.Button(foot, text="Save a copy of data.csv ...", command=self.save_copy).pack(side="left", padx=8)
        ttk.Button(foot, text="Known-pressure check ...", command=self.known_pressure).pack(side="left")
        self.where = tk.StringVar(value="")
        tk.Label(foot, textvariable=self.where, bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="right")

    # ------------------------------------------------------------------ helpers
    def _ports(self) -> list[str]:
        try:
            from serial.tools import list_ports
            return [p.device for p in list_ports.comports()]
        except Exception:
            return []

    def _say(self, text: str, tagged: list | None = None) -> None:
        self.report.configure(state="normal")
        self.report.delete("1.0", "end")
        for line, tag in (tagged or [(text, None)]):
            self.report.insert("end", line + "\n", tag or ())
        self.report.configure(state="disabled")

    def _busy(self, on: bool) -> None:
        state = "disabled" if on else "normal"
        self.start_btn.configure(state=state)
        self.test_btn.configure(state=state)
        self.plan_btn.configure(state=state)
        self.check_btn.configure(state=state)
        self.stop_btn.configure(state="normal" if on else "disabled")
        self.pump_var.set("Pump ON" if on else "Pump off")
        self.pump_lbl.configure(fg="#ff8a80" if on else "#9be39b")

    def pick_level(self) -> None:
        """Fill in AC, DC, heart rate and run time from a target level. The values stay editable."""
        pair = LEVELS[self.v["level"].get()]
        if pair:
            self.v["shape"].set("two-sine")
            self.v["ac"].set(f"{pair[0]:g}")
            self.v["dc"].set(f"{pair[1]:g}")
            self.v["hr"].set("60")
            self.v["seconds"].set("90")
            self.status.set("Values filled in from the earlier runs (AC %g, DC %g, 90 s). Edit them if you wish." % pair)

    def preset_flush(self) -> None:
        self.v["level"].set("custom")
        self.v["shape"].set("flat")
        self.v["ac"].set("0")
        self.v["dc"].set("3.0")
        self.v["seconds"].set("60")
        self.status.set("Flush settings filled in. Press START.")

    def _cfg(self, test: bool) -> dict | None:
        try:
            cfg = dict(ac=float(self.v["ac"].get()), dc=float(self.v["dc"].get()), hr=float(self.v["hr"].get()),
                       seconds=float(self.v["seconds"].get()), shape=self.v["shape"].get(), psi=float(self.v["psi"].get().split()[0]),
                       port=self.v["port"].get().strip(), demo=self.demo.get(), test=test)
            core.check_inputs(cfg["ac"], cfg["dc"], cfg["hr"], cfg["seconds"])
        except ValueError as exc:
            messagebox.showwarning("Settings", str(exc) if "pump" in str(exc) or "AC" in str(exc) or "Heart" in str(exc) else "All fields must be numbers.")
            return None
        return cfg

    # ------------------------------------------------------------------ actions
    def check_board(self) -> None:
        self.link_var.set("Checking the board ...")

        def job():
            try:
                b = core.DemoBoard() if self.demo.get() else core.Board(self.v["port"].get().strip() or None)
                self.q.put(("link", f"Connected  {b.port}"))
                b.close()
            except Exception as exc:          # noqa: BLE001
                self.q.put(("link", "No board: " + str(exc)[:70]))
        threading.Thread(target=job, daemon=True).start()

    def start(self, test: bool) -> None:
        cfg = self._cfg(test)
        if cfg is None or self.thread:
            return
        what = "sine, two-sine and human, 20 s each, at this AC and DC" if test else ("flat DC %g V, no pulse" % cfg["dc"] if cfg["ac"] == 0 else
                                                                                       "%s: %g to %g V" % (cfg["shape"], cfg["dc"], cfg["dc"] + cfg["ac"]))
        if not messagebox.askokcancel("Start", f"{what}\nScale: {cfg['psi']:g} psi.\n\nIs the pump OFF and the loop at rest?\n"
                                      "The sensors are zeroed now, then the pump starts.\nSTOP switches it off."):
            return
        self.t, self.p1, self.p2, self.cmd, self.echo = [], [], [], [], []
        self.stop_ev.clear()
        self._busy(True)
        self._say("Running. The check appears when the run ends.")
        self.thread = threading.Thread(target=run_job, args=(cfg, lambda k, x: self.q.put((k, x)), self.stop_ev), daemon=True)
        self.thread.start()

    def start_plan(self) -> None:
        if self.thread:
            return
        path = filedialog.askopenfilename(title="Choose a plan file (CSV: shape, ac, dc, hr, seconds, rest_s)", initialdir=core.HERE,
                                          filetypes=[("Plan CSV", "*.csv")])
        if not path:
            return
        try:
            plan = core.read_plan(path)
            cfg = self._cfg(False)
        except ValueError as exc:
            return messagebox.showwarning("Plan file", str(exc))
        if cfg is None:
            return
        minutes = sum(p["seconds"] + p["rest_s"] + 3 for p in plan) / 60.0
        if not messagebox.askokcancel("Run the plan", f"{len(plan)} tests, about {minutes:.0f} minutes.\nScale: {cfg['psi']:g} psi.\n\n"
                                      "The pump rests OFF between tests and is zeroed before each one.\nSTOP ends the plan and switches the pump off."):
            return
        self.stop_ev.clear()
        self._busy(True)
        self._say("Running the plan. A summary appears here when it ends.")
        self.thread = threading.Thread(target=plan_job, args=(plan, cfg, lambda k, x: self.q.put((k, x)), self.stop_ev), daemon=True)
        self.thread.start()

    def on_close(self) -> None:
        """Closing the window while the pump runs stops it first, so the pump is never left on."""
        if self.thread:
            self.stop_ev.set()
            self.thread.join(timeout=4.0)
        self.root.destroy()

    def stop(self) -> None:
        self.stop_ev.set()
        self.status.set("Stopping, the pump is going off ...")

    def open_run(self) -> None:
        if self.folder and os.name == "nt":
            os.startfile(self.folder)

    def save_copy(self) -> None:
        if not self.folder:
            return
        dest = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"{self.folder.name}.csv", filetypes=[("CSV", "*.csv")])
        if dest:
            shutil.copy2(self.folder / "data.csv", dest)

    def known_pressure(self) -> None:
        if not self.folder:
            return messagebox.showinfo("Known pressure", "Do a run first. Then apply a known pressure (water column) with the pump off, "
                                       "read what P1 shows, and enter both here.")
        win = tk.Toplevel(self.root)
        win.title("Known-pressure check")
        win.configure(bg=CARD)
        known, seen = tk.StringVar(), tk.StringVar()
        tk.Label(win, text="Pump off, a known pressure on P1 (50 cm of water = 36.8 mmHg).", bg=CARD, font=(FONT, 10)).grid(row=0, column=0, columnspan=2, padx=16, pady=(14, 8))
        for i, (txt, var) in enumerate((("Known pressure (mmHg)", known), ("P1 showed (mmHg)", seen)), start=1):
            tk.Label(win, text=txt, bg=CARD, font=(FONT, 10)).grid(row=i, column=0, sticky="e", padx=10, pady=4)
            ttk.Entry(win, textvariable=var, width=9).grid(row=i, column=1, sticky="w")

        def save():
            try:
                k, m = float(known.get()), float(seen.get())
            except ValueError:
                return messagebox.showwarning("Known pressure", "Enter two numbers.")
            meta = json.loads((self.folder / "meta.json").read_text(encoding="utf-8"))
            meta["reference_check"] = {"known_mmHg": k, "measured_mmHg": m}
            (self.folder / "meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
            self._show(verify.check_folder(self.folder), meta)
            win.destroy()
        ttk.Button(win, text="Save and re-check", command=save).grid(row=3, column=0, columnspan=2, pady=14)

    # ------------------------------------------------------------------ live updates
    def _show(self, items, meta) -> None:
        lines = [(f"[{i['status']:4}] {i['name']:<18} {i['detail']}", i["status"]) for i in items]
        n = {s: sum(i["status"] == s for i in items) for s in COLOR}
        lines.append(("   ".join(f"{k} {v}" for k, v in n.items() if v) + ("   DATA NOT TRUSTED" if n["FAIL"] else "   no failures"),
                      "FAIL" if n["FAIL"] else "PASS"))
        self._say("", lines)

    def _poll(self) -> None:
        got = False
        while True:
            try:
                kind, val = self.q.get_nowait()
            except queue.Empty:
                break
            if kind == "row":
                self.t.append(len(self.t) / core.RATE)
                self.p1.append(val["p1_mmHg"])
                self.p2.append(val["p2_mmHg"])
                self.cmd.append(val["cmd_V"])
                self.echo.append(val["pump_V"])
                got = True
            elif kind == "reset":
                self.t, self.p1, self.p2, self.cmd, self.echo = [], [], [], [], []
            elif kind == "beat":
                self.period = val
            elif kind == "plan_done":
                self.thread = None
                self._busy(False)
                out, summary, total = val
                self.folder = out
                self.where.set("saved: runs/" + out.name)
                lines = [(f"Plan: {len(summary)} of {total} tests done.  Summary: plan_summary.csv", "PASS" if len(summary) == total else "WARN")]
                for r in summary:
                    st = "FAIL" if r["fail"] else ("WARN" if r["warn"] else "PASS")
                    lines.append((f"[{st:4}] test {r['test']}: {r['shape']} AC {r['ac_V']:g} DC {r['dc_V']:g}  P1 {r['p1_min']:.0f} to {r['p1_max']:.0f}  P2 {r['p2_min']:.0f} to {r['p2_max']:.0f} mmHg  "
                                  f"checks: {r['pass']} pass, {r['warn']} warn, {r['fail']} fail" + ("" if r["ended"] == "finished" else f"  ({r['ended']})"), st))
                self._say("", lines)
                self.status.set("Plan finished." if len(summary) == total else "Plan ended early.")
                self._draw()
            elif kind == "status":
                self.status.set(val)
            elif kind == "link":
                self.link_var.set(val)
            elif kind == "error":
                self.thread = None
                self._busy(False)
                self.status.set("Stopped: " + val)
                messagebox.showerror("Could not run", val)
            elif kind == "done":
                self.thread = None
                self._busy(False)
                self.folder, items, meta = val
                self.status.set(("Finished" if meta["ended"] == "finished" else "Ended: " + meta["ended"]) + f". {len(self.t) / core.RATE:.0f} s saved.")
                self.where.set("saved: runs/" + self.folder.name)
                self._show(items, meta)
                self._draw()
        if got:
            n = int(0.5 * core.RATE)
            self.tile["p1"].set(f"{np.nanmean(self.p1[-n:]):.1f}")
            self.tile["p2"].set(f"{np.nanmean(self.p2[-n:]):.1f}")
            self.tile["v"].set(f"{self.cmd[-1]:.2f}")
            self.status.set(f"Running: {self.t[-1]:.0f} s")
            self._draw()
        self.root.after(250 if self.thread else 100, self._poll)

    @staticmethod
    def _fit(ax, *series, min_span: float, pad: float = 0.12) -> None:
        """Fit the y axis to the data on screen, never tighter than min_span (so noise is not stretched into waves)."""
        vals = np.concatenate([np.asarray(s, float).ravel() for s in series])
        vals = vals[np.isfinite(vals)]
        if not vals.size:
            return
        lo, hi = float(vals.min()), float(vals.max())
        span = max(hi - lo, min_span)
        mid = (hi + lo) / 2
        ax.set_ylim(mid - span / 2 - pad * span, mid + span / 2 + pad * span)

    def _draw(self) -> None:
        a1, a2 = self.ax1, self.ax2
        a1.clear()
        a2.clear()
        if self.t:
            sel = self.zoom.get()
            n = len(self.t) if sel == "Whole run" else int(float(sel.split()[0]) * core.RATE)
            t = self.t[-n:]
            p1, p2, cmd, echo = (np.asarray(x[-n:], float) for x in (self.p1, self.p2, self.cmd, self.echo))
            a1.plot(t, p1, lw=2.2, color="#8C2D2D", label=f"P1 inlet  {np.nanmin(p1):.0f} to {np.nanmax(p1):.0f} mmHg")
            a1.plot(t, p2, lw=1.8, color="#4A78A6", label=f"P2 outlet  {np.nanmin(p2):.0f} to {np.nanmax(p2):.0f} mmHg")
            self._fit(a1, p1, p2, min_span=MIN_SPAN_MMHG)
            a1.legend(loc="lower left", bbox_to_anchor=(0.0, 1.0), fontsize=9, ncol=2, frameon=False)
            a2.plot(t, echo, lw=1.4, color="#999999", ls="--", label="echoed by the board")
            a2.plot(t, cmd, lw=2.2, color=MAROON, label="commanded")
            self._fit(a2, cmd, echo, min_span=0.5, pad=0.2)
            a2.legend(loc="lower left", bbox_to_anchor=(0.0, 1.0), fontsize=9, ncol=2, frameon=False)
        else:
            a1.text(0.5, 0.5, "P1 and P2 appear here while it runs", ha="center", va="center", transform=a1.transAxes, color="#9A9090", fontsize=12)
        a1.set_ylabel("pressure (mmHg)", fontsize=10, color=MUTED)
        a2.set_ylabel("pump voltage (V)", fontsize=10, color=MUTED)
        a2.set_xlabel("time (s)", fontsize=10, color=MUTED)
        self._draw_beat()
        for a in (a1, a2, self.ax3, self.ax3v):
            a.tick_params(labelsize=9, colors=MUTED)
            a.spines["top"].set_visible(False)
        for a in (a1, a2, self.ax3):
            a.spines["right"].set_visible(False)
            a.grid(alpha=0.3)
        self.fig.tight_layout()
        self.canvas.draw_idle()

    def _draw_beat(self) -> None:
        """Every beat of the run laid on top of the others (last 10): the pressure waveform and the voltage that made it."""
        ax, axv = self.ax3, self.ax3v
        ax.clear()
        axv.clear()
        axv.yaxis.tick_right()                                           # clear() on a twin axis puts its ticks and label back on the left
        axv.yaxis.set_label_position("right")
        ax.set_title("One beat, all beats overlaid", loc="left", fontsize=10, color=MAROON, fontweight="bold", pad=34)
        T = self.period
        spb = T * core.RATE if T else 0
        nb = int(len(self.t) // spb) if spb else 0
        if not T or nb < 2:
            ax.text(0.5, 0.5, "No beat to show:\nflat voltage or a waveform test" if not T else "Needs 2 complete beats", ha="center", va="center",
                    transform=ax.transAxes, color="#9A9090", fontsize=11)
            ax.set_xticks([])
            ax.set_yticks([])
            axv.set_yticks([])
            return
        ks = range(max(1 if nb > 3 else 0, nb - 10), nb)                 # skip the first beat (start-up) when there are enough
        x = np.linspace(0, T, 100)

        def fold(series):
            a = np.asarray(series, float)
            return np.array([np.interp(np.linspace(0, 1, 100), np.linspace(0, 1, len(seg)), seg)
                             for seg in (a[int(round(k * spb)):int(round((k + 1) * spb))] for k in ks)])
        f1, f2, fc = fold(self.p1), fold(self.p2), fold(self.cmd)
        for row in f1:
            ax.plot(x, row, lw=0.9, color="#8C2D2D", alpha=0.25)
        m1, m2 = f1.mean(axis=0), f2.mean(axis=0)
        ax.plot(x, m1, lw=3.0, color="#8C2D2D", label="P1 average beat")
        ax.plot(x, m2, lw=2.2, color="#4A78A6", label="P2 average beat")
        self._fit(ax, m1, m2, f1, min_span=MIN_SPAN_MMHG, pad=0.15)
        axv.plot(x, fc.mean(axis=0), lw=1.8, color="#777777", ls="--", label="pump voltage")
        self._fit(axv, fc.mean(axis=0), min_span=0.5, pad=0.3)
        ax.set_xlim(0, T)
        ax.set_xlabel("time within the beat (s)", fontsize=10, color=MUTED)
        ax.set_ylabel("pressure (mmHg)", fontsize=10, color=MUTED)
        axv.set_ylabel("pump voltage (V)", fontsize=10, color="#777777")
        ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.14), fontsize=8, ncol=3, frameon=False, handles=ax.get_lines()[-2:] + axv.get_lines())
        ax.text(0.0, 1.02, f"P1 average beat {m1.min():.0f} to {m1.max():.0f} mmHg, pulse height {np.ptp(m1):.0f}\n"
                           f"beat-to-beat spread {f1.std(axis=0).mean():.1f} mmHg, {len(f1)} beats", transform=ax.transAxes, va="bottom", fontsize=9, color=INK)


def selftest() -> int:
    """No window, no board: a 6 s demo flush through connect, zero, run, save and check."""
    import tempfile
    core.RUNS = Path(tempfile.mkdtemp())                 # the self-test leaves nothing in the runs folder
    out, stop = queue.Queue(), threading.Event()
    run_job(dict(ac=0.0, dc=3.0, hr=60.0, seconds=6.0, shape="flat", psi=15.0, port="", demo=True, test=False, fast=True), lambda k, v: out.put((k, v)), stop)
    kinds = {}
    while not out.empty():
        k, v = out.get()
        kinds[k] = v
    ok = "done" in kinds and not any(i["status"] == "FAIL" for i in kinds["done"][1])
    plan = [dict(shape="flat", ac=0.0, dc=3.0, hr=60.0, seconds=4.0, rest_s=0.0), dict(shape="two-sine", ac=0.6, dc=2.0, hr=60.0, seconds=6.0, rest_s=0.0)]
    plan_job(plan, dict(psi=15.0, port="", demo=True, fast=True), lambda k, v: out.put((k, v)), stop)
    while not out.empty():
        k, v = out.get()
        kinds[k] = v
    ok = ok and "plan_done" in kinds and len(kinds["plan_done"][1]) == 2 and (kinds["plan_done"][0] / "plan_summary.csv").exists()
    print("Phantom Lab self-test:", "OK" if ok else f"FAILED ({kinds.get('error')})")
    return 0 if ok else 1


def main() -> int:
    if "--selftest" in sys.argv:
        return selftest()
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    root = tk.Tk()
    App(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
