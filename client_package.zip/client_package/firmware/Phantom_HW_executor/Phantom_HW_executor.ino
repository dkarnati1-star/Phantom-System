// =====================================================================================
// Phantom_HW_executor.ino
// Arduino Portenta H7 = HARDWARE EXECUTOR ONLY
//
// Python owns:
//   - waveform generation (pressure.py, morphology.py)
//   - AC/DC interpretation
//   - target SYS/DIA
//   - feedback controller
//   - zero calibration
//   - CSV logging
//
// Arduino owns:
//   - AD5693R DAC output
//   - ADC121C021 P1/P2 raw reads
//   - immediate command/response
//   - host-loss pump failsafe
//
// I2C:
//   P1 inlet ADC  = 0x55
//   P2 outlet ADC = 0x54
//   Pump DAC      = 0x4C or 0x4E
//
// Serial: 115200 baud, ASCII lines
//
// PC -> Arduino:
//   PING
//   CHECK
//   STEP <volts>
//   PUMP OFF
//   VOUT                (only useful when PUMP_SENSE_ENABLED, see below)
//
// Arduino -> PC:
//   #PONG
//   #CHECK,p1=OK,p2=OK,dac=OK@0x4C,vmax=5.00,drive_max=3.30,dac_vdd=3.30,ext_gain=1.00,
//          dac_errors=0,i2c_recoveries=0,last_reset=NORMAL,system=READY
//   #OK,PUMP OFF
//   #VOUT,cmd=<volts>,meas=<volts>   or   #VOUT,cmd=<volts>,meas=DISABLED
//   D,<t_ms>,<seq>,<raw1>,<ok1>,<raw2>,<ok2>,<pump_v>
//
//   pump_v in the D line is the voltage the pump can ACTUALLY get
//   (the request clamped to drive_max), not just the number Python asked for.
//
// IMPORTANT:
//   Arduino DOES NOT create a sine wave and DOES NOT calculate blood pressure.
//   Python sends every pump-voltage sample with STEP.
//
// PUMP DRIVE (why the pressure stopped at ~80 mmHg):
//   The AD5693R with gain x2 needs VDD >= VREF + 1.5 V = 4.0 V. Powered from the
//   Portenta's 3.3 V its output stops at ~3.3 V, so STEP 3.3 .. 5.0 all gave the
//   pump the same ~3.3 V. Logged sweeps fit a hard clip at 3.3 V (1.7 mmHg RMS).
//   Set DAC_SUPPLY_V and EXT_AMP_GAIN below to match the real wiring:
//
//     Wiring                                   DAC_GAIN2  DAC_SUPPLY_V  EXT_AMP_GAIN  drive_max
//     DAC on 3.3 V (current, suspected)         true       3.3           1.0           3.3 V
//     DAC VIN on 5 V (check I2C levels first)   true       5.0           1.0           5.0 V
//     DAC on 3.3 V + x2 op-amp on 5 V rail      false      3.3           2.0           5.0 V
// =====================================================================================

#include <Wire.h>
#include "drivers/Watchdog.h"
#include "drivers/ResetReason.h"

// ---------------- Hardware settings ----------------
const uint8_t ADDR_P1 = 0x55;
const uint8_t ADDR_P2 = 0x54;

// Highest pump voltage Python may request.
const float VMAX = 5.0f;

// DAC output range: true -> 0..5 V (needs DAC VDD >= 4.0 V), false -> 0..2.5 V.
const bool DAC_GAIN2 = true;

// Supply voltage on the DAC breakout VIN. The DAC output can never exceed it.
const float DAC_SUPPLY_V = 3.3f;

// Gain of any amplifier between the DAC output and the pump input (1.0 = none).
const float EXT_AMP_GAIN = 1.0f;

// Optional pump-voltage readback: pump input -> divider -> Portenta analog pin.
// Use a divider so the pin never sees more than 3.3 V (10k/10k halves 5 V to 2.5 V).
const bool PUMP_SENSE_ENABLED = false;
const int PUMP_SENSE_PIN = A0;
const float PUMP_SENSE_DIVIDER = 2.0f;
const float ANALOG_REF_V = 3.3f;
const float ANALOG_FULL_SCALE = 65535.0f;

const uint8_t N_AVG = 4;

// Python normally sends STEP at ~50 Hz.
// If Python stops sending valid commands while pump is active,
// Arduino forces pump to zero.
const uint32_t HOST_FAILSAFE_MS = 500;

// If the DAC browns out or resets, it powers up at gain x1 and the pump gets
// half the requested voltage. Re-send the control word every this many STEPs
// (25 = every 0.5 s at 50 Hz) and after any failed write.
const uint32_t DAC_REFRESH_STEPS = 25;

// If the firmware ever stops running (e.g. an I2C read that never returns because
// of a loose SDA/SCL/GND wire), the watchdog resets the board within this time.
// setup() turns the pump off first thing, so a hang can never leave it running.
const uint32_t WATCHDOG_TIMEOUT_MS = 2000;

// After this many failed ADC reads in a row, restart the I2C peripheral.
const uint8_t I2C_RECOVER_AFTER_FAILS = 5;

// Boot attempts to reach the DAC (and set the pump to 0 V) before giving up.
const uint8_t DAC_BOOT_ATTEMPTS = 5;


// ---------------- State ----------------
uint8_t dacAddr = 0;

// Nominal DAC span for the chosen gain (code 65535 -> this voltage).
const float dacFullScale = DAC_GAIN2 ? 5.0f : 2.5f;

// What the DAC can really output: nominal span, limited by its own supply.
const float dacOutMax = (DAC_SUPPLY_V < dacFullScale) ? DAC_SUPPLY_V : dacFullScale;

// Highest voltage the pump can really receive.
const float driveMaxV = (dacOutMax * EXT_AMP_GAIN < VMAX) ? dacOutMax * EXT_AMP_GAIN : VMAX;

float pumpV = 0.0f;

uint32_t seq = 0;

// Failed DAC writes since boot (reported in CHECK as dac_errors).
uint32_t dacErrors = 0;

// I2C health, reported in CHECK.
uint8_t adcFailStreak = 0;
uint32_t i2cRecoveries = 0;
bool lastResetWasWatchdog = false;

uint32_t lastHostCommandMs = 0;

bool hostWasConnected = false;

String rxLine;


// =====================================================================================
// ADC121C021
// =====================================================================================

int adcRaw(uint8_t addr)
{
    // Select conversion register 0x00, repeated-start read.
    Wire.beginTransmission(addr);
    Wire.write((uint8_t)0x00);

    if (Wire.endTransmission(false) != 0)
    {
        adcFailStreak++;
        return -1;
    }

    if (Wire.requestFrom(addr, (uint8_t)2) != 2)
    {
        adcFailStreak++;
        return -1;
    }

    adcFailStreak = 0;

    uint8_t msb = Wire.read();
    uint8_t lsb = Wire.read();

    uint16_t raw = (((uint16_t)msb << 8) | lsb) & 0x0FFF;

    return (int)raw;
}


void i2cBegin()
{
    Wire.begin();
    Wire.setClock(100000);
}


// Free a bus held low by a device stuck mid-transfer: clock SCL up to 9 times until
// SDA is released, then send a STOP. Called before Wire.begin() in setup().
void i2cClearBus()
{
    pinMode(I2C_SDA, INPUT_PULLUP);
    pinMode(I2C_SCL, OUTPUT);
    digitalWrite(I2C_SCL, HIGH);

    for (uint8_t i = 0; i < 9 && digitalRead(I2C_SDA) == LOW; i++)
    {
        digitalWrite(I2C_SCL, LOW);
        delayMicroseconds(5);
        digitalWrite(I2C_SCL, HIGH);
        delayMicroseconds(5);
    }

    // STOP: SDA low -> high while SCL is high.
    pinMode(I2C_SDA, OUTPUT);
    digitalWrite(I2C_SDA, LOW);
    delayMicroseconds(5);
    digitalWrite(I2C_SCL, HIGH);
    delayMicroseconds(5);
    digitalWrite(I2C_SDA, HIGH);
    delayMicroseconds(5);
}


// Restart the I2C peripheral and re-apply the DAC setting after repeated failures.
void i2cRecover()
{
    Wire.end();
    delay(2);
    i2cBegin();
    i2cRecoveries++;
    adcFailStreak = 0;

    if (dacAddr)
    {
        dacConfigure();
    }
}


float adcAvg(uint8_t addr)
{
    // Discard one read first.
    adcRaw(addr);

    long sum = 0;
    int good = 0;

    for (uint8_t i = 0; i < N_AVG; i++)
    {
        int r = adcRaw(addr);

        if (r >= 0)
        {
            sum += r;
            good++;
        }
    }

    if (adcFailStreak >= I2C_RECOVER_AFTER_FAILS)
    {
        i2cRecover();
    }

    if (good == 0)
    {
        return -1.0f;
    }

    return (float)sum / (float)good;
}


bool adcAlive(uint8_t addr)
{
    return adcRaw(addr) >= 0;
}


// Generic I2C presence. Used only for DAC.
bool i2cPresent(uint8_t addr)
{
    Wire.beginTransmission(addr);
    return Wire.endTransmission() == 0;
}


// =====================================================================================
// AD5693R
// =====================================================================================

bool dacWrite16(uint8_t cmd, uint16_t data)
{
    if (!dacAddr)
    {
        return false;
    }

    Wire.beginTransmission(dacAddr);
    Wire.write(cmd);
    Wire.write((uint8_t)(data >> 8));
    Wire.write((uint8_t)(data & 0xFF));

    return Wire.endTransmission() == 0;
}


bool dacInit()
{
    if (i2cPresent(0x4C))
    {
        dacAddr = 0x4C;
    }
    else if (i2cPresent(0x4E))
    {
        // Alternate AD5693R address if A0 is configured differently.
        dacAddr = 0x4E;
    }
    else
    {
        dacAddr = 0;
        return false;
    }

    // Control register: normal power, internal reference, gain selected.
    return dacConfigure();
}


// Normal power, internal reference, chosen gain.
bool dacConfigure()
{
    uint16_t ctrl = DAC_GAIN2 ? 0x0800 : 0x0000;

    return dacWrite16(0x40, ctrl);
}


void setPumpVolts(float v)
{
    if (v < 0.0f)
    {
        v = 0.0f;
    }

    // Clamp to what the hardware can really deliver, so pump_v in the
    // D line reports the truth instead of an unreachable request.
    if (v > driveMaxV)
    {
        v = driveMaxV;
    }

    pumpV = v;

    if (!dacAddr)
    {
        return;
    }

    // Pump voltage -> DAC output voltage (undo any external amplifier) -> code.
    float dacV = v / EXT_AMP_GAIN;
    uint32_t code = (uint32_t)(dacV / dacFullScale * 65535.0f + 0.5f);

    if (code > 65535UL)
    {
        code = 65535UL;
    }

    // Write DAC register + update output.
    if (!dacWrite16(0x30, (uint16_t)code))
    {
        dacErrors++;

        // Reconfigure and retry once so a DAC reset does not leave it at gain x1.
        dacConfigure();
        dacWrite16(0x30, (uint16_t)code);
    }
}


void pumpOff()
{
    setPumpVolts(0.0f);
}


// =====================================================================================
// HARDWARE CHECK
// =====================================================================================

void printCheck()
{
    // ADC121C021 health is checked with a real conversion-register read,
    // not a generic address scan.
    bool p1 = adcAlive(ADDR_P1);
    bool p2 = adcAlive(ADDR_P2);

    if (!dacAddr)
    {
        dacInit();
    }

    bool dac = dacAddr && i2cPresent(dacAddr);

    Serial.print("#CHECK,p1=");
    Serial.print(p1 ? "OK" : "MISSING");

    Serial.print(",p2=");
    Serial.print(p2 ? "OK" : "MISSING");

    Serial.print(",dac=");
    if (dac)
    {
        Serial.print("OK@0x");
        Serial.print(dacAddr, HEX);
    }
    else
    {
        Serial.print("MISSING");
    }

    Serial.print(",vmax=");
    Serial.print(VMAX, 2);

    Serial.print(",drive_max=");
    Serial.print(driveMaxV, 2);

    Serial.print(",dac_vdd=");
    Serial.print(DAC_SUPPLY_V, 2);

    Serial.print(",ext_gain=");
    Serial.print(EXT_AMP_GAIN, 2);

    Serial.print(",dac_errors=");
    Serial.print(dacErrors);

    Serial.print(",i2c_recoveries=");
    Serial.print(i2cRecoveries);

    Serial.print(",last_reset=");
    Serial.print(lastResetWasWatchdog ? "WATCHDOG" : "NORMAL");

    Serial.print(",system=");
    Serial.println((p1 && p2 && dac) ? "READY" : "FAULT");
}


// =====================================================================================
// PUMP VOLTAGE READBACK (optional)
// =====================================================================================

void printVout()
{
    Serial.print("#VOUT,cmd=");
    Serial.print(pumpV, 3);
    Serial.print(",meas=");

    if (!PUMP_SENSE_ENABLED)
    {
        Serial.println("DISABLED");
        return;
    }

    long sum = 0;
    for (uint8_t i = 0; i < N_AVG; i++)
    {
        sum += analogRead(PUMP_SENSE_PIN);
    }

    float pinV = (float)sum / N_AVG / ANALOG_FULL_SCALE * ANALOG_REF_V;
    Serial.println(pinV * PUMP_SENSE_DIVIDER, 3);
}


// =====================================================================================
// EXECUTE ONE PUMP SAMPLE
// =====================================================================================

void executeStep(float requestedV)
{
    // 1. Apply voltage from Python.
    setPumpVolts(requestedV);

    // 2. Read inlet and outlet pressure ADCs.
    float r1 = adcAvg(ADDR_P1);
    float r2 = adcAvg(ADDR_P2);

    seq++;

    if (dacAddr && seq % DAC_REFRESH_STEPS == 0)
    {
        if (!dacConfigure())
        {
            dacErrors++;
        }
    }

    // 3. Return result to Python.
    // Format: D,time_ms,seq,p1raw,p1ok,p2raw,p2ok,pumpV
    Serial.print("D,");
    Serial.print(millis());
    Serial.print(",");
    Serial.print(seq);
    Serial.print(",");
    Serial.print(r1, 1);
    Serial.print(",");
    Serial.print(r1 >= 0.0f ? 1 : 0);
    Serial.print(",");
    Serial.print(r2, 1);
    Serial.print(",");
    Serial.print(r2 >= 0.0f ? 1 : 0);
    Serial.print(",");
    Serial.println(pumpV, 4);
}


// =====================================================================================
// COMMAND HANDLER
// =====================================================================================

void handleCommand(String cmd)
{
    cmd.trim();

    if (cmd.length() == 0)
    {
        return;
    }

    String upper = cmd;
    upper.toUpperCase();

    // Only valid commands refresh the failsafe timer.
    // Garbage or rejected commands must not keep the pump running.

    if (upper == "PING")
    {
        lastHostCommandMs = millis();
        Serial.println("#PONG");
        return;
    }

    if (upper == "CHECK")
    {
        lastHostCommandMs = millis();
        printCheck();
        return;
    }

    if (upper == "PUMP OFF")
    {
        lastHostCommandMs = millis();
        pumpOff();
        Serial.println("#OK,PUMP OFF");
        return;
    }

    if (upper == "VOUT")
    {
        lastHostCommandMs = millis();
        printVout();
        return;
    }

    if (upper.startsWith("STEP "))
    {
        String valueText = cmd.substring(5);
        valueText.trim();

        if (valueText.length() == 0)
        {
            Serial.println("#ERR,usage: STEP <volts>");
            return;
        }

        float v = valueText.toFloat();

        if (isnan(v) || isinf(v) || v < 0.0f || v > VMAX)
        {
            Serial.println("#ERR,STEP voltage outside 0..VMAX");
            return;
        }

        if (!dacAddr)
        {
            Serial.println("#ERR,pump DAC not found");
            return;
        }

        lastHostCommandMs = millis();
        executeStep(v);
        return;
    }

    Serial.print("#ERR,unknown command: ");
    Serial.println(cmd);
}


// =====================================================================================
// SETUP
// =====================================================================================

void setup()
{
    // Safety first: pump OFF before anything else, including after a watchdog reset.
    // The DAC keeps its last output through a board reset, so the bus is cleared and
    // the DAC is retried until the 0 V write reaches it.
    for (uint8_t attempt = 0; attempt < DAC_BOOT_ATTEMPTS && !dacAddr; attempt++)
    {
        i2cClearBus();
        i2cBegin();
        dacInit();
        if (!dacAddr)
        {
            Wire.end();
            delay(20);
        }
    }
    pumpOff();

    lastResetWasWatchdog = (mbed::ResetReason::get() == RESET_REASON_WATCHDOG);

    Serial.begin(115200);

    // Wait briefly for USB.
    while (!Serial && millis() < 4000)
    {
        delay(10);
    }

    analogReadResolution(16);

    delay(500);

    lastHostCommandMs = millis();

    Serial.print("#READY,Phantom_HW_EXECUTOR,last_reset=");
    Serial.println(lastResetWasWatchdog ? "WATCHDOG" : "NORMAL");

    printCheck();

    mbed::Watchdog::get_instance().start(WATCHDOG_TIMEOUT_MS);
}


// =====================================================================================
// LOOP
// =====================================================================================

void loop()
{
    mbed::Watchdog::get_instance().kick();

    // USB disconnect safety.
    bool host = (bool)Serial;

    if (hostWasConnected && !host)
    {
        pumpOff();
    }

    hostWasConnected = host;

    // Host-loss failsafe.
    if (pumpV > 0.0f && (millis() - lastHostCommandMs) > HOST_FAILSAFE_MS)
    {
        pumpOff();
    }

    // Receive Python commands.
    while (Serial.available())
    {
        char c = (char)Serial.read();

        if (c == '\n' || c == '\r')
        {
            if (rxLine.length() > 0)
            {
                handleCommand(rxLine);
                rxLine = "";
            }
        }
        else if (rxLine.length() < 80)
        {
            rxLine += c;
        }
    }
}
