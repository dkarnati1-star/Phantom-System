@echo off
rem Phantom Lab: double-click this file to open the app.
rem First time only: it installs the three Python packages the app needs.
cd /d "%~dp0"

set PY=
where python >nul 2>nul && set PY=python
if not defined PY where py >nul 2>nul && set PY=py -3
if not defined PY (
    echo Python is not installed. Install Python 3.10 or newer from python.org and tick "Add Python to PATH", then run this again.
    pause
    exit /b 1
)

%PY% -c "import serial, numpy, matplotlib" >nul 2>nul
if errorlevel 1 (
    echo Installing the needed packages, one time only ...
    %PY% -m pip install -r requirements.txt
)

%PY% phantom_lab.py %*
if errorlevel 1 pause
