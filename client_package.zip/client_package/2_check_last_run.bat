@echo off
rem Double-click to run the data check on the most recent run in the runs folder.
rem To check another run:  2_check_last_run.bat runs\<folder name>
cd /d "%~dp0"

set PY=
where python >nul 2>nul && set PY=python
if not defined PY where py >nul 2>nul && set PY=py -3
if not defined PY (
    echo Python is not installed. See README.md.
    pause
    exit /b 1
)

set TARGET=%~1
if not defined TARGET (
    for /f "delims=" %%d in ('dir /b /ad /o-d runs 2^>nul') do (
        set TARGET=runs\%%d
        goto found
    )
    echo There are no runs yet. Run the app first.
    pause
    exit /b 1
)
:found
echo Checking %TARGET%
echo.
%PY% phantom_verify.py "%TARGET%"
echo.
echo The report and plot.png are saved inside that run folder.
pause
