function items = phantom_check(folder)
% PHANTOM_CHECK  Plot a Phantom Lab run and repeat the data checklist independently of the Python program.
%
%   phantom_check                    asks you to choose a run folder (the one holding data.csv and meta.json)
%   phantom_check('runs/2026-10-19_10-30-00_flush')
%   items = phantom_check(folder);   items is a struct array with fields status, name, detail
%
% It uses only base MATLAB (no toolbox). The checks and thresholds are the same as phantom_verify.py, so the two
% reports should agree. If they do not, one of them has a bug: tell the developer which line differs.
%
% data.csv columns: pc_time, board_ms, seq, cmd_V, pump_V, p1_raw, p2_raw, p1_mmHg, p2_mmHg, ok1, ok2   (50 samples/s)

if nargin < 1 || isempty(folder)
    folder = uigetdir(pwd, 'Choose a run folder (data.csv and meta.json)');
    if isequal(folder, 0), return; end
end
T = readtable(fullfile(folder, 'data.csv'));
meta = jsondecode(fileread(fullfile(folder, 'meta.json')));
fs = 50;
n = height(T);
t = (0:n-1)' / fs;
p1 = T.p1_mmHg;  p2 = T.p2_mmHg;
ac = getf(meta, 'ac_V', NaN);  dc = getf(meta, 'dc_V', NaN);  hr = getf(meta, 'hr_bpm', 60);
segs = getf(meta, 'segments', []);
hasSegs = ~isempty(segs);
flat = ac == 0 && ~hasSegs;
steady = t >= min(5, 0.25 * t(end));
items = struct('status', {}, 'name', {}, 'detail', {});

% 1 Sampling
gaps = sum(diff(T.seq) ~= 1);
dtb = diff(T.board_ms);
ok = gaps == 0 && abs(median(dtb) - 20) <= 2 && max(dtb) < 60;
if ok, st = 'PASS'; elseif gaps <= 0.005 * n && max(dtb) < 200, st = 'WARN'; else, st = 'FAIL'; end
items = add(items, st, '1 Sampling', sprintf('%d samples, %d gaps in seq, median spacing %.0f ms, longest %.0f ms', n, gaps, median(dtb), max(dtb)));

% 2 Sensors valid
bad = 100 * (1 - min(mean(T.ok1), mean(T.ok2)));
stuck = std(T.p1_raw, 1) == 0 || std(T.p2_raw, 1) == 0;
sat = 100 * max(mean(T.p1_raw <= 1 | T.p1_raw >= 4094), mean(T.p2_raw <= 1 | T.p2_raw >= 4094));
if stuck || bad > 1 || sat > 2, st = 'FAIL'; elseif bad > 0 || sat > 0, st = 'WARN'; else, st = 'PASS'; end
items = add(items, st, '2 Sensors valid', sprintf('%.2f%% samples flagged bad, %.2f%% at the ADC limits, stuck sensor: %d', bad, sat, stuck));

% 3 Zero
if isfield(meta, 'zero_spread_p1')
    sp = max(meta.zero_spread_p1, meta.zero_spread_p2);
    if sp < 5, st = 'PASS'; elseif sp < 10, st = 'WARN'; else, st = 'FAIL'; end
    items = add(items, st, '3 Zero (pump off)', sprintf('zero counts P1 %.1f, P2 %.1f; spread %.1f counts', meta.zero_p1, meta.zero_p2, sp));
else
    items = add(items, 'WARN', '3 Zero (pump off)', 'no zero information in meta.json');
end

% 4 Command applied
echo = max(abs(T.pump_V - T.cmd_V));
if echo < 0.01, st = 'PASS'; elseif echo < 0.05, st = 'WARN'; else, st = 'FAIL'; end
detail = sprintf('board echo differs from the command by at most %.4f V; command %.3f to %.3f V', echo, min(T.cmd_V), max(T.cmd_V));
if ~isnan(ac) && ~hasSegs && (abs(min(T.cmd_V) - dc) > 0.005 || abs(max(T.cmd_V) - (dc + ac)) > 0.005)
    st = 'FAIL';  detail = [detail sprintf('; expected %g to %g V', dc, dc + ac)];
end
items = add(items, st, '4 Command applied', detail);

% 5 Counts to mmHg
if isfield(meta, 'zero_p1') && isfield(meta, 'mmHg_per_count')
    g = meta.mmHg_per_count;
    d = max(max(abs((T.p1_raw - meta.zero_p1) * g - p1)), max(abs((T.p2_raw - meta.zero_p2) * g - p2)));
    if d < 0.01, st = 'PASS'; else, st = 'FAIL'; end
    items = add(items, st, '5 Counts to mmHg', sprintf('recomputed from raw counts, zero and %.4f mmHg/count (%g psi): largest difference %.4f mmHg', g, meta.psi, d));
else
    items = add(items, 'WARN', '5 Counts to mmHg', 'no zero or scale in meta.json');
end

% 6 Response
if flat
    w = steady & t >= t(end) - 20;
    a = p1(w);  half = floor(numel(a) / 2);
    drift = abs(mean(a(half+1:end)) - mean(a(1:half)));
    level = mean(a, 'omitnan');
    low = dc >= 1.5 && level < 5;
    if low || drift > 2, st = 'WARN'; else, st = 'PASS'; end
    items = add(items, st, '6 Response', sprintf('flat DC %g V: P1 settled at %.1f mmHg, changed %.1f mmHg between the last two halves', dc, level, drift));
else
    [lag, c] = lagcorr(T.cmd_V(steady), p1(steady), fs);
    if lag >= 0.03 && lag <= 0.4 && c >= 0.9, st = 'PASS'; elseif c >= 0.7, st = 'WARN'; else, st = 'FAIL'; end
    items = add(items, st, '6 Response', sprintf('P1 follows the command with a delay of %.0f ms (correlation %.3f)', lag * 1000, c));
end

% 7 Repeatability
if flat || hasSegs
    items = add(items, 'N/A', '7 Repeatability', 'flat run or mixed-shape test: no repeating beat');
else
    bn = round(fs * 60 / hr);
    idx = find(steady);
    nb = floor(numel(idx) / bn);
    if nb >= 3
        beats = reshape(p1(idx(1):idx(1) + nb * bn - 1), bn, nb);
        ssd = std(max(beats, [], 1), 1);  dsd = std(min(beats, [], 1), 1);
        m = max(ssd, dsd);
        if m <= 2, st = 'PASS'; elseif m <= 4, st = 'WARN'; else, st = 'FAIL'; end
        items = add(items, st, '7 Repeatability', sprintf('%d beats: systolic varies %.2f mmHg, diastolic %.2f mmHg (standard deviation)', nb, ssd, dsd));
    else
        items = add(items, 'WARN', '7 Repeatability', 'fewer than 3 beats after the settling time');
    end
end

% 8 P1 and P2
dmean = mean(p1 - p2, 'omitnan');
detail = sprintf('P1 minus P2 averages %.1f mmHg', dmean);
c2 = NaN;
if ~flat && std(p1(steady), 1) > 0
    r = corrcoef(p1(steady), p2(steady));  c2 = r(1, 2);
    detail = [detail sprintf('; they move together (correlation %.3f)', c2)];
end
if dmean > 0 && (isnan(c2) || c2 >= 0.95), st = 'PASS'; else, st = 'WARN'; end
items = add(items, st, '8 P1 and P2', detail);

% 9 Known pressure (manual)
if isfield(meta, 'reference_check')
    e = meta.reference_check.measured_mmHg - meta.reference_check.known_mmHg;
    if abs(e) <= 3, st = 'PASS'; else, st = 'FAIL'; end
    items = add(items, st, '9 Known pressure', sprintf('known %g mmHg, read %g (error %+.1f)', meta.reference_check.known_mmHg, meta.reference_check.measured_mmHg, e));
else
    items = add(items, 'TODO', '9 Known pressure', 'not done: apply a known pressure (water column) and enter it; see CHECKLIST.md step 6');
end

% 10 Waveform test
if hasSegs
    parts = cell(numel(segs), 3);
    for k = 1:numel(segs)
        m = t >= segs(k).start_s + 5 & t < segs(k).end_s;
        parts(k, :) = {segs(k).shape, T.cmd_V(m), p1(m)};
    end
    c0 = parts{1, 2};  p0 = parts{1, 3};
    best = Inf;  lagB = 0;  tauB = 0;  coef = [0 0];
    for lag = 0:0.02:0.30
        for tau = [0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30]
            x = lagfilter(c0, lag, tau, fs);
            pf = polyfit(x, p0, 1);
            err = sum((p0 - (pf(1) * x + pf(2))).^2);
            if err < best, best = err; lagB = lag; tauB = tau; coef = pf; end
        end
    end
    txt = '';  worst = Inf;
    for k = 2:size(parts, 1)
        fit = coef(1) * lagfilter(parts{k, 2}, lagB, tauB, fs) + coef(2);
        y = parts{k, 3};
        r2 = 1 - sum((y - fit).^2) / sum((y - mean(y)).^2);
        txt = [txt sprintf('%s %.3f  ', parts{k, 1}, r2)];
        worst = min(worst, r2);
    end
    if worst >= 0.9, st = 'PASS'; elseif worst >= 0.7, st = 'WARN'; else, st = 'FAIL'; end
    items = add(items, st, '10 Waveform test', sprintf('model fitted on %s only (delay %.0f ms, lag %.0f ms, %.1f mmHg/V); predicts the others with R2 %s', parts{1, 1}, lagB * 1000, tauB * 1000, coef(1), strtrim(txt)));
else
    items = add(items, 'N/A', '10 Waveform test', 'run the Waveform test button to check that P1 follows any shape');
end

% report
fprintf('\nPhantom run check (MATLAB)  %s  AC %g V  DC %g V  %g psi scale\n', string(getf(meta, 'shape', '?')), ac, dc, getf(meta, 'psi', NaN));
for k = 1:numel(items)
    fprintf('[%-4s] %-18s %s\n', items(k).status, items(k).name, items(k).detail);
end
nfail = sum(strcmp({items.status}, 'FAIL'));
if nfail, fprintf('-> %d FAIL: DATA NOT TRUSTED\n', nfail); else, fprintf('-> no failures\n'); end

% plots: pressures, then the pump voltage that produced them, then the raw counts
figure('Name', 'Phantom run', 'Color', 'w');
ax1 = subplot(3, 1, 1);  plot(t, p1, 'Color', [0.55 0.18 0.18]);  hold on;  plot(t, p2, 'Color', [0.29 0.47 0.65]);
ylabel(sprintf('mmHg (%g psi scale)', getf(meta, 'psi', NaN)));  legend('P1 inlet', 'P2 outlet', 'Location', 'northeast');  grid on;
ax2 = subplot(3, 1, 2);  plot(t, T.cmd_V, 'Color', [0.31 0 0], 'LineWidth', 1.2);  hold on;  plot(t, T.pump_V, '--', 'Color', [0.6 0.6 0.6]);
ylabel('pump voltage (V)');  legend('commanded', 'echoed by the board', 'Location', 'northeast');  grid on;
ax3 = subplot(3, 1, 3);  plot(t, T.p1_raw, 'Color', [0.55 0.18 0.18]);  hold on;  plot(t, T.p2_raw, 'Color', [0.29 0.47 0.65]);
ylabel('ADC counts');  xlabel('time (s)');  grid on;
linkaxes([ax1 ax2 ax3], 'x');
end

% ----------------------------------------------------------------------------------------------- helpers
function items = add(items, status, name, detail)
items(end + 1) = struct('status', status, 'name', name, 'detail', detail);
end

function v = getf(s, name, default)
if isfield(s, name) && ~isempty(s.(name)), v = s.(name); else, v = default; end
end

function [lag, best] = lagcorr(cmd, p, fs)
% delay (s) at which p best follows cmd, and the correlation there (lags 0 to 0.6 s)
best = -1;  lag = 0;
c = cmd - mean(cmd);  q = p - mean(p);
for k = 0:round(0.6 * fs)
    a = c(1:end - k);  b = q(1 + k:end);
    if std(a) > 0 && std(b) > 0
        r = corrcoef(a, b);
        if r(1, 2) > best, best = r(1, 2);  lag = k / fs; end
    end
end
end

function out = lagfilter(cmd, lag, tau, fs)
% pure delay, then a first-order lag: the simplest model of "the pump and phantom delay and smooth the command"
k = round(lag * fs);
x = [repmat(cmd(1), k, 1); cmd(:)];
x = x(1:numel(cmd));
alpha = (1 / fs) / (tau + 1 / fs);
y = x(1);
out = zeros(size(x));
for i = 1:numel(x)
    y = y + alpha * (x(i) - y);
    out(i) = y;
end
end
