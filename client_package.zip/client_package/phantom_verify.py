"""
phantom_verify.py: is this run's data legitimate? Reads a run folder (data.csv + meta.json) and prints a checklist.

    python phantom_verify.py runs/2026-10-19_10-30-00_flush          writes report.txt and plot.png in that folder

Every line is PASS, WARN, FAIL, N/A (does not apply to this run) or TODO (a manual step, see CHECKLIST.md).
The same checks, with the same thresholds, are in matlab/phantom_check.m so the numbers can be compared.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

from phantom_core import RATE, gain, read_run

SKIP_S = 5.0                                  # settling time ignored by the response and repeatability checks


def _item(name: str, status: str, detail: str) -> dict:
    return {"name": name, "status": status, "detail": detail}


def _lag_corr(cmd: np.ndarray, p: np.ndarray, max_lag_s: float = 0.6):
    """Delay (s) at which P best follows the command, and the correlation there."""
    best = (0.0, -1.0)
    c, q = cmd - cmd.mean(), p - p.mean()
    for k in range(int(max_lag_s * RATE) + 1):
        a, b = c[: len(c) - k], q[k:]
        if a.std() > 0 and b.std() > 0:
            r = float(np.corrcoef(a, b)[0, 1])
            if r > best[1]:
                best = (k / RATE, r)
    return best


def _filtered(cmd: np.ndarray, lag_s: float, tau_s: float) -> np.ndarray:
    """Pure delay then a first-order lag: the simplest model of 'the pump and phantom smooth and delay the command'."""
    k = int(round(lag_s * RATE))
    x = np.concatenate([np.full(k, cmd[0]), cmd])[: len(cmd)]
    alpha, y, out = (1.0 / RATE) / (tau_s + 1.0 / RATE), x[0], np.empty(len(x))
    for i, v in enumerate(x):
        y += alpha * (v - y)
        out[i] = y
    return out


def _r2(y: np.ndarray, fit: np.ndarray) -> float:
    return 1.0 - float(np.sum((y - fit) ** 2) / np.sum((y - y.mean()) ** 2))


def _waveform_test(d: dict, segs: list) -> dict:
    """Fit delay, lag, gain and offset on the sine segment only, then predict the other two shapes (never fitted)."""
    t = np.arange(len(d["cmd_V"])) / RATE
    parts = []
    for s in segs:
        m = (t >= s["start_s"] + 5.0) & (t < s["end_s"])
        parts.append((s["shape"], d["cmd_V"][m], d["p1_mmHg"][m]))
    shape0, c0, p0 = parts[0]
    best = None
    for lag in np.arange(0.0, 0.32, 0.02):
        for tau in (0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.15, 0.2, 0.25, 0.3):
            x = _filtered(c0, lag, tau)
            a, b = np.polyfit(x, p0, 1)
            err = float(np.sum((p0 - (a * x + b)) ** 2))
            if best is None or err < best[0]:
                best = (err, lag, tau, a, b)
    _, lag, tau, a, b = best
    out = {"fit_on": shape0, "lag_s": lag, "tau_s": tau, "mmHg_per_V": a, "r2": {shape0: _r2(p0, a * _filtered(c0, lag, tau) + b)}}
    for shape, c, p in parts[1:]:
        out["r2"][shape] = _r2(p, a * _filtered(c, lag, tau) + b)
    return out


def verify(d: dict, meta: dict) -> list[dict]:
    n = len(d["seq"])
    t = np.arange(n) / RATE
    ac, dc, hr = meta.get("ac_V"), meta.get("dc_V"), meta.get("hr_bpm", 60.0)
    segs = meta.get("segments") or []
    flat = ac == 0 and not segs
    steady = t >= min(SKIP_S, 0.25 * t[-1])
    r = []

    # 1 Sampling
    gaps = int(np.sum(np.diff(d["seq"]) != 1))
    dtb = np.diff(d["board_ms"])
    ok = gaps == 0 and abs(np.median(dtb) - 20) <= 2 and dtb.max() < 60
    r.append(_item("1 Sampling", "PASS" if ok else ("WARN" if gaps <= 0.005 * n and dtb.max() < 200 else "FAIL"),
                   f"{n} samples, {gaps} gaps in seq, median spacing {np.median(dtb):.0f} ms, longest {dtb.max():.0f} ms"))

    # 2 Sensors valid
    bad = 100.0 * (1.0 - min(d["ok1"].mean(), d["ok2"].mean()))
    stuck = any(np.std(d[k]) == 0 for k in ("p1_raw", "p2_raw"))
    sat = 100.0 * max(np.mean((d[k] <= 1) | (d[k] >= 4094)) for k in ("p1_raw", "p2_raw"))
    st = "FAIL" if stuck or bad > 1 or sat > 2 else ("WARN" if bad > 0 or sat > 0 else "PASS")
    r.append(_item("2 Sensors valid", st, f"{bad:.2f}% samples flagged bad, {sat:.2f}% at the ADC limits, "
                   f"{'a sensor is stuck' if stuck else 'both sensors vary'}"))

    # 3 Zero
    if "zero_spread_p1" in meta:
        sp = max(meta["zero_spread_p1"], meta["zero_spread_p2"])
        r.append(_item("3 Zero (pump off)", "PASS" if sp < 5 else ("WARN" if sp < 10 else "FAIL"),
                       f"zero counts P1 {meta['zero_p1']:.1f}, P2 {meta['zero_p2']:.1f}; spread {sp:.1f} counts"))
    else:
        r.append(_item("3 Zero (pump off)", "WARN", "no zero information in meta.json"))

    # 4 Command applied
    echo = float(np.max(np.abs(d["pump_V"] - d["cmd_V"])))
    detail = f"board echo differs from the command by at most {echo:.4f} V; command {d['cmd_V'].min():.3f} to {d['cmd_V'].max():.3f} V"
    st = "PASS" if echo < 0.01 else ("WARN" if echo < 0.05 else "FAIL")
    if ac is not None and not segs and (abs(d["cmd_V"].min() - dc) > 0.005 or abs(d["cmd_V"].max() - (dc + ac)) > 0.005):
        st, detail = "FAIL", detail + f"; expected {dc:g} to {dc + ac:g} V"
    r.append(_item("4 Command applied", st, detail))

    # 5 Conversion
    if "zero_p1" in meta and "mmHg_per_count" in meta:
        g = meta["mmHg_per_count"]
        diff = max(float(np.nanmax(np.abs((d["p1_raw"] - meta["zero_p1"]) * g - d["p1_mmHg"]))),
                   float(np.nanmax(np.abs((d["p2_raw"] - meta["zero_p2"]) * g - d["p2_mmHg"]))))
        r.append(_item("5 Counts to mmHg", "PASS" if diff < 0.01 else "FAIL",
                       f"recomputed from raw counts, zero and {g:.4f} mmHg/count ({meta['psi']:g} psi): largest difference {diff:.4f} mmHg"))
    else:
        r.append(_item("5 Counts to mmHg", "WARN", "no zero or scale in meta.json"))

    # 6 Response
    p1 = d["p1_mmHg"]
    if flat:
        a_, b_ = p1[steady & (t >= t[-1] - 20)], p1[steady & (t >= t[-1] - 20)]
        half = len(a_) // 2
        drift = abs(float(np.mean(a_[half:]) - np.mean(a_[:half])))
        level = float(np.nanmean(a_))
        low = dc is not None and dc >= 1.5 and level < 5
        r.append(_item("6 Response", "WARN" if low or drift > 2 else "PASS",
                       f"flat DC {dc:g} V: P1 settled at {level:.1f} mmHg, changed {drift:.1f} mmHg between the last two halves"
                       + ("; almost no pressure for this voltage: check pump, tubing and air" if low else "")))
    else:
        lag, corr = _lag_corr(d["cmd_V"][steady], p1[steady])
        st = "PASS" if 0.03 <= lag <= 0.4 and corr >= 0.9 else ("WARN" if corr >= 0.7 else "FAIL")
        r.append(_item("6 Response", st, f"P1 follows the command with a delay of {lag * 1000:.0f} ms (correlation {corr:.3f})"))

    # 7 Repeatability
    if flat or segs:
        r.append(_item("7 Repeatability", "N/A", "flat run or mixed-shape test: no repeating beat"))
    else:
        bn = int(round(RATE * 60.0 / hr))
        idx = np.flatnonzero(steady)
        nb = len(idx) // bn
        if nb >= 3:
            beats = p1[idx[0]: idx[0] + nb * bn].reshape(nb, bn)
            ssd, dsd = float(beats.max(1).std()), float(beats.min(1).std())
            r.append(_item("7 Repeatability", "PASS" if max(ssd, dsd) <= 2 else ("WARN" if max(ssd, dsd) <= 4 else "FAIL"),
                           f"{nb} beats: systolic varies {ssd:.2f} mmHg, diastolic {dsd:.2f} mmHg (standard deviation)"))
        else:
            r.append(_item("7 Repeatability", "WARN", "fewer than 3 beats after the settling time"))

    # 8 P1 vs P2
    diff = float(np.nanmean(p1 - d["p2_mmHg"]))
    corr2 = float(np.corrcoef(p1[steady], d["p2_mmHg"][steady])[0, 1]) if not flat and np.std(p1[steady]) > 0 else None
    st = "PASS" if diff > 0 and (corr2 is None or corr2 >= 0.95) else "WARN"
    r.append(_item("8 P1 and P2", st, f"P1 minus P2 averages {diff:.1f} mmHg" + ("" if corr2 is None else f"; they move together (correlation {corr2:.3f})")
                   + ("" if diff > 0 else "; P2 is above P1: check which sensor is the inlet")))

    # 9 Reference (manual)
    ref = meta.get("reference_check")
    if ref:
        err = ref["measured_mmHg"] - ref["known_mmHg"]
        r.append(_item("9 Known pressure", "PASS" if abs(err) <= 3 else "FAIL", f"known {ref['known_mmHg']:g} mmHg, read {ref['measured_mmHg']:g} (error {err:+.1f})"))
    else:
        r.append(_item("9 Known pressure", "TODO", "not done: apply a known pressure (water column) and enter it; see CHECKLIST.md step 6"))

    # 10 Waveform test
    if segs:
        w = _waveform_test(d, segs)
        worst = min(v for k, v in w["r2"].items() if k != w["fit_on"])
        st = "PASS" if worst >= 0.9 else ("WARN" if worst >= 0.7 else "FAIL")
        r.append(_item("10 Waveform test", st, f"model fitted on {w['fit_on']} only (delay {w['lag_s'] * 1000:.0f} ms, lag {w['tau_s'] * 1000:.0f} ms, "
                       f"{w['mmHg_per_V']:.1f} mmHg/V); predicts the others with R2 " + ", ".join(f"{k} {v:.3f}" for k, v in w["r2"].items() if k != w["fit_on"])))
    else:
        r.append(_item("10 Waveform test", "N/A", "run the Waveform test button to check that P1 follows any shape"))
    return r


def report(items: list[dict], meta: dict) -> str:
    head = (f"Phantom run check   shape {meta.get('shape')}  AC {meta.get('ac_V')} V  DC {meta.get('dc_V')} V  {meta.get('psi')} psi scale  "
            f"feedback: {meta.get('feedback', '?')}{'  (DEMO, no hardware)' if meta.get('demo') else ''}")
    lines = [head, "-" * len(head)] + [f"[{i['status']:4}] {i['name']:<18} {i['detail']}" for i in items]
    count = {s: sum(i["status"] == s for i in items) for s in ("PASS", "WARN", "FAIL", "TODO", "N/A")}
    lines.append("-" * len(head))
    lines.append("   ".join(f"{k} {v}" for k, v in count.items() if v) + ("   -> DATA NOT TRUSTED" if count["FAIL"] else "   -> no failures"))
    return "\n".join(lines)


def save_plot(d: dict, meta: dict, path: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    t = np.arange(len(d["seq"])) / RATE
    fig, ax = plt.subplots(3, 1, figsize=(11, 8), sharex=True)
    ax[0].plot(t, d["p1_mmHg"], color="#8C2D2D", lw=1, label="P1 inlet")
    ax[0].plot(t, d["p2_mmHg"], color="#4A78A6", lw=1, label="P2 outlet")
    ax[0].set_ylabel(f"mmHg ({meta.get('psi')} psi scale)")
    ax[0].legend(loc="upper right", ncol=2, frameon=False)
    ax[1].plot(t, d["cmd_V"], color="#500000", lw=1.2, label="commanded")
    ax[1].plot(t, d["pump_V"], color="#999999", lw=1, ls="--", label="echoed by the board")
    ax[1].set_ylabel("pump voltage (V)")
    ax[1].legend(loc="upper right", ncol=2, frameon=False)
    ax[2].plot(t, d["p1_raw"], color="#8C2D2D", lw=1, label="P1 counts")
    ax[2].plot(t, d["p2_raw"], color="#4A78A6", lw=1, label="P2 counts")
    ax[2].set_ylabel("ADC counts")
    ax[2].set_xlabel("time (s)")
    ax[2].legend(loc="upper right", ncol=2, frameon=False)
    for a in ax:
        a.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


def check_folder(folder: Path | str, plot: bool = True) -> list[dict]:
    folder = Path(folder)
    d, meta = read_run(folder)
    items = verify(d, meta)
    (folder / "report.txt").write_text(report(items, meta), encoding="utf-8")
    if plot:
        save_plot(d, meta, folder / "plot.png")
    return items


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit(__doc__)
    folder = Path(sys.argv[1])
    check_folder(folder, plot="--no-plot" not in sys.argv)
    print((folder / "report.txt").read_text(encoding="utf-8"))
